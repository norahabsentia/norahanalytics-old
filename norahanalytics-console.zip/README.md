[![Build Status](https://travis-ci.org/norahabsentia/norahanalytics-console.svg?branch=master)](https://travis-ci.org/norahabsentia/norahanalytics-console)

* Deploys here - [https://norahanalytics-console.firebaseapp.com/](https://norahanalytics-console.firebaseapp.com/#/pages/dashboard)

* Ensure your node version is 6.11.3

* If you face @angular/devkit.... errors try reinstalling the angular/cli

* For developement use ```ng serve --aot=true``` this will solve the reflector.guards error.



init-new
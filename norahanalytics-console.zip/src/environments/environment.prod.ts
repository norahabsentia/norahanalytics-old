/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyCdiOM6VI5dwfyMkuMMw2e86pEd5tJKy8U",
    authDomain: "notificationpage-3af4c.firebaseapp.com",
    databaseURL: "https://notificationpage-3af4c.firebaseio.com",
    projectId: "notificationpage-3af4c",
    storageBucket: "",
    messagingSenderId: "1076209267766"
  }
};

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'churn-predictions',
  templateUrl: './churn-predictions.component.html',
  styleUrls: ['./churn-predictions.component.scss']
})
export class ChurnPredictionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

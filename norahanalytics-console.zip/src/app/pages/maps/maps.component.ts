import { Component } from '@angular/core';

@Component({
  selector: 'ngx-maps',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class MapsComponent {
}

export class Notification {
    noti_ID : string;
    title : string;
    body : string;
    deeplink : string;
    Customer_Segment_ID  : any=[];
}

import {NgModule} from '@angular/core';

import {PagesComponent} from './pages.component';
import {DashboardModule} from './dashboard/dashboard.module';
import {PagesRoutingModule} from './pages-routing.module';
import {ThemeModule} from '../@theme/theme.module';
import {GameOverviewModule} from './game-overview/game-overview.module';
import { ChurnPredictionsComponent } from './churn-predictions/churn-predictions.component';

const PAGES_COMPONENTS = [
  PagesComponent,
];

@NgModule({
  imports: [
    PagesRoutingModule,
    ThemeModule,
    DashboardModule,
    GameOverviewModule,
  ],
  declarations: [
    ...PAGES_COMPONENTS,
    ChurnPredictionsComponent,
  ],
})
export class PagesModule {
}
